﻿// Demonstration of C# parameter passing
using System;

namespace Parameters {
    class Program {
        // Does not work
        static void OnArray2(int[] arr) {
            arr = new int[2] { 0, 1 };
        }
        // Does work
        static void OnArray3(ref int[] arr) {
            arr = new int[2] { 0, 1 };
        }

        // out parameters assumed unassigned
        static void OnArray4(out int[] arr) {
            arr[0] = 1;
        }

        // C# way to swap 2 strings
        static void SwapString(ref string a,ref string b) {
            var tmp = a;
            a = b;
            b = tmp;
        }
        // Generic version
        static void Swap<T>(ref T a,ref T b) {
            var tmp = a;
            a = b;
            b = tmp;
        }

        static void Main(string[] args) {
            string s1 = "1st", s2 = "2nd";

            SwapString(ref s1, ref s2);
            Console.WriteLine("{0} {1}", s1, s2);

            Swap(ref s1, ref s2);
            Console.WriteLine("{0} {1}", s1, s2);
        }
    }
}
