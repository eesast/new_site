﻿// Demonstration of simple C# class
using System;

namespace Classes {
    class Person {
        // Field
        string name = "";  // Fields can be assigned when declared
        public const string defaultName = "Unkonwn";
        public static DateTime firstTime;

        // Static method
        static void Main() {
            Person david = new Person();
            Person amy;    //amy = null

            Console.WriteLine(Person.firstTime);   // static members accessed using class.member
            Console.WriteLine(Person.defaultName); // const members is implicitly static
        }

        // Method
        public string SayHello(string anotherName) {
            return string.Format("Hello, {0}. I'm {1}", anotherName, name);  // C# ways of formating string
        }

        // Default instance constructor
        public Person(string name = defaultName) {
            this.name = name;   // this means this instance
        }

        // Static constructor
        static Person() {
            firstTime = DateTime.Now; // Assign value to static fields
        }

        // Property 
        public string Name {
            get { return name; }   // get accessor: return a value
            set { name = value; }  // set accessor: get a value
        }

        // Indexer
        public char this[int i] {
            get { return name[i];}
            // set accessor omitted
        }
    }
}
