﻿// Demonstration of operator overloading to implement complex number type
using System;

namespace OperatorOverload {
    public struct Complex {
        public double real;
        public double imaginary;

        // Constructor.
        public Complex(double real, double imaginary) {
            this.real = real;
            this.imaginary = imaginary;
        }

        // Implicit conversion from double
        public static implicit operator Complex(double real) => new Complex(real, 0);

        // Specify which operator to overload (+), 
        // the types that can be added (two Complex objects),
        // and the return type (Complex).
        public static Complex operator +(Complex c1, Complex c2)
            => new Complex(c1.real + c2.real, c1.imaginary + c2.imaginary);

        // Override the ToString() method to display a complex number 
        // in the traditional format:
        public override string ToString() {
            return (string.Format("{0} + {1}i", real, imaginary));
        }
    }

    class Program {
        static void Main(string[] args) {
            Complex num1 = new Complex(2, 3);
            // int -> double -> Complex using implicit conversion
            Complex num2 = 1;

            // Add two Complex objects by using the overloaded + operator.
            Complex sum = num1 + num2;

            // Print the numbers and the sum by using the overridden ToString method. 
            Console.WriteLine("The complex number: {0}, the sum with {1}: {2}", num1, num2, sum);
        }
    }
}
