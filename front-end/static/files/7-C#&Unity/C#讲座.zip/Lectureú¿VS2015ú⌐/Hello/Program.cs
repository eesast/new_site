﻿//A Hello World! program in C#
using System;
using static System.Console;

namespace Hello {
    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Hello World!");

            WriteLine("Hello World!");
        }
    }
}
