﻿// Demonstration of C# delegate
using System;

namespace Delegates {
    class MethodClass {
        public int i;

        // Instance method for the delegate
        public void Method(string message) {
            Console.WriteLine(message);
            Console.WriteLine("i = {0}", i);
        }
    }

    class Program {
        // Declare a delegate type
        delegate void Del(string message);

        // Create a method for the delegate.
        public static void DelegateMethod(string message) {
            Console.WriteLine(message);
        }

        static void Main(string[] args) {
            // Instantiate the delegate.
            Del handler = DelegateMethod;
            // Another way to instantiate the delegate
            Del hendler2 = new Del(DelegateMethod); 

            // Call the delegate to call the methods respectively
            handler("hehe");

            // Delegate can add multiple methods
            // Instance method also supported, no matter what the object is
            handler -= DelegateMethod;
            MethodClass cls1 = new MethodClass();
            cls1.i = 1;
            handler += cls1.Method;

            MethodClass cls2 = new MethodClass();
            cls2.i = 2;
            handler += cls2.Method;

            handler("another hehe");  // i = 1 i = 2
        } 
    }
}
