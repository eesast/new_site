﻿// Demonstration of variables of various C# types
using System;

// string is C# keyword,cannot be identifier, so use @string instead.
// BTW, @"C:\Program Files" equals "C:\\Program Files", @ prevents escape sequences processing
namespace @string {
    class Program {
        static void Main(string[] args) {
            object obj;             // Declaration only, default value is null
            int myInt1 = new int(); // Equivalent: int myInt1 = 0

            int myInt2; // Declaration only,cannot be used until assigned
            Console.WriteLine(myInt2);

            bool myShort = 1;            // int cannot implicitly convert to bool
            float myFloat = 0.0;         // double cannot implicitly convert to float

            decimal myDecimal = 0.0M;    //suffix M Stands for decimal literal

            var myString = "A String";   //Equivalent: string myString = "A String"
            var myVar;                   //var must come with initialization

            // Dynamic types like Python
            dynamic dy = 1;
            Console.WriteLine(dy.GetType());  // System.Int32
            dy = "A String";
            Console.WriteLine(dy.GetType());  // System.String
        }
    }
}
