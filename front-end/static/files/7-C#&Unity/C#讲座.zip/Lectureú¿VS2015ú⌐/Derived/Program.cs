﻿// Demonstration ofthe keywords: base this
using System;

namespace Derived {
    class BaseClass {
        public BaseClass() {
            Console.WriteLine("in BaseClass()");
        }

        public BaseClass(int i) {
            Console.WriteLine("in BaseClass(int)");
        }

        public virtual void Fun() {
            Console.WriteLine("in BaseClass.Fun()");
        }
    }

    class DerivedClass: BaseClass {
        // This constructor will call BaseClass.BaseClass()
        public DerivedClass() : base() {
            Console.WriteLine("in DerivedClass()");
        }

        // This constructor will call BaseClass.BaseClass(int i)
        public DerivedClass(int i) : base(i) {
            Console.WriteLine("in DerivedClass(int)");
        }

        // This constructor will call DerivedClass.DerivedClass()
        public DerivedClass(float f) : this() {
            Console.WriteLine("in DerivedClass(float)");
        }

        public override void Fun() {
            // Call BaseClass.Fun()
            base.Fun();
            Console.WriteLine("in DerivedClass.Fun()");
        }

        static void Main() {
            DerivedClass md = new DerivedClass();
            Console.WriteLine();
            DerivedClass md1 = new DerivedClass(1);
            Console.WriteLine();
            DerivedClass md2 = new DerivedClass(1.0F);
        }
    }

}
