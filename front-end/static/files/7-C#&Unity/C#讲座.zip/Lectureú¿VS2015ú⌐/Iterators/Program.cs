﻿// Demonstration of C# iterators
using System;
using System.Collections;

namespace Iterators {
    class Program {
        static void Main() {
            // foreach on the iterator
            foreach(ulong fib in Fibonacci())
                Console.WriteLine(fib);
        }

        // An iterator must return IEnumerable
        static IEnumerable Fibonacci() {
            ulong a = 1, b = 1;// f(1) and f(2)
               
            yield return a;    // Return f(1)

            // Loop until overflow
            while(true) { 
                yield return b;// Return f(n)
                try {
                    // f(n+2) = f(n+1) + f(n)
                    ulong tmp = b;
                    checked { b = a + b; }
                    a = tmp;
                }
                catch(OverflowException) {
                    // Stop Iterating
                    yield break;
                }
            }
        }
    }
}
