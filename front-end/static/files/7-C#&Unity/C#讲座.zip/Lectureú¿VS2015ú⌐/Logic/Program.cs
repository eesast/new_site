﻿// Demonstration of logical operators vs conditional operators
using System;

namespace LogicOperators {
    class Program {
        static void Main(string[] args) {
            int i = 0;
            if(false & ++i == 1) {
                // This block does not execute.
            }
            Console.WriteLine(i); // 1

            i = 0;
            if(false && ++i == 1) {
                // This block does not execute.
            }
            Console.WriteLine(i); // 0
        }
    }
}
