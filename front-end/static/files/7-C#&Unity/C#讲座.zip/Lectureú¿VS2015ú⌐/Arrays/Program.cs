﻿// Demonstration of C# arrays
using System;

namespace Arrays {
    class Program {
        static void Main(string[] args) {
            // Declare a single-dimensional array 
            int[] array1 = new int[3] { 1, 2, 3 };
            int[] array2 = new int[] { 1, 2 };
            int[] array3 = new[] { 1, 3 };
            int[] array4 = { 5, 7, 9 };

            var array5 = new int[5];
            var array6 = new[] { 1, 9 };
            var array7 = { 1, 9 };   // var must come with new[]

            // Declare a two dimensional array
            int[,] multiDimensionalArray1 = new int[2, 3];
            var multiDimensionalArray2 = new[,] { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] multiDimensionalArray3 = { { 1, 2, 3 }, { 4, 5, 6 } };
            
            // Length means the number of all the elements inside
            Console.WriteLine(multiDimensionalArray1.Length);  // 2 * 3 = 6
            // Rank means the number of dimensions
            Console.WriteLine(multiDimensionalArray1.Rank);    // 2

            // Declare a jagged array
            var jaggedArray = new int[2][];
            // Set the values of arrays in the jagged array structure
            jaggedArray[0] = new int[] { 1, 2, 3, 4 };
            jaggedArray[1] = new int[] { 5, 6, 7 };

            // Inner arrays have nothing to do with the length and rank of outter arrays.
            Console.WriteLine(jaggedArray.Length);             // 2
            Console.WriteLine(jaggedArray.Rank);               // 1
        }
    }
}
