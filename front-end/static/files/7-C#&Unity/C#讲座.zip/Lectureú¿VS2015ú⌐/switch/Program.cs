﻿// Demonstration of switch statement
using System;

namespace Switch {
    class Program {
        static void Main() {
            string input = Console.ReadLine();
            switch(input) {
                case "Hello!":
                    Console.WriteLine("Hi!");
                    break;
                case "How are you?":
                    Console.WriteLine("I'm fine.");
                    break;
                default:
                    Console.WriteLine("Sorry, what did you say?");
                    break;
            }
        }
    }
}
